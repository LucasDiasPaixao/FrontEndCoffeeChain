﻿namespace WebApplication1.Models
{
    public class list<T>
    {
        public object Propriedades { get; internal set; }
    }
}